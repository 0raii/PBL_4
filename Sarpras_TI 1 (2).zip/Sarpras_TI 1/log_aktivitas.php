<?php
include 'config.php';

// Cek apakah user adalah admin
if (!isset($_SESSION['id']) || $_SESSION['role'] != 'admin') {
    header("Location: index.php");
    exit();
}

// Ambil data log login
$query_login = "
    SELECT l.id, l.user_id, l.login_time, l.ip_address, 
           m.namaLengkap, m.username, m.role
    FROM `login` l
    JOIN mahasiswa m ON l.user_id = m.id
    ORDER BY l.login_time DESC
";
$result_login = mysqli_query($conn, $query_login);

// Ambil data log logout
$query_logout = "
    SELECT lo.id, lo.user_id, lo.logout_time, lo.ip_address, 
           m.namaLengkap, m.username, m.role
    FROM `logout` lo
    JOIN mahasiswa m ON lo.user_id = m.id
    ORDER BY lo.logout_time DESC
";
$result_logout = mysqli_query($conn, $query_logout);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log Aktivitas - Sistem Peminjaman Sarpras</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>Sarpras TI</h2>
            </div>
            
            <div class="sidebar-user">
                <div class="user-avatar">
                    <i class="fas fa-user-shield"></i>
                </div>
                <div class="user-info">
                    <h3><?php echo $_SESSION['namaLengkap']; ?></h3>
                    <p>Administrator</p>
                </div>
            </div>
            
            <ul class="sidebar-menu">
                <li><a href="dashboard_admin.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="approval.php"><i class="fas fa-check-circle"></i> Approval Peminjaman</a></li>
                <li><a href="ruangan.php"><i class="fas fa-building"></i> Manajemen Ruangan</a></li>
                <li><a href="unit.php"><i class="fas fa-tools"></i> Manajemen Unit</a></li>
                <li><a href="mahasiswa.php"><i class="fas fa-users"></i> Manajemen User</a></li>
                <li class="active"><a href="log_aktivitas.php"><i class="fas fa-history"></i> Log Aktivitas</a></li>
                <li><a href="laporan.php"><i class="fas fa-chart-bar"></i> Laporan</a></li>
                <li><a href="process/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Log Aktivitas Pengguna</h1>
                <div class="header-info">
                    <span><?php echo date('d F Y'); ?></span>
                </div>
            </div>
            
            <!-- Tabs -->
            <div class="tabs">
                <div class="tab active" data-tab="login">Log Login</div>
                <div class="tab" data-tab="logout">Log Logout</div>
            </div>
            
            <!-- Tab Content -->
            <div class="tab-content">
                <!-- Login Tab -->
                <div id="login" class="tab-pane active">
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User</th>
                                    <th>Role</th>
                                    <th>Waktu Login</th>
                                    <th>IP Address</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (mysqli_num_rows($result_login) > 0): ?>
                                    <?php while ($log = mysqli_fetch_assoc($result_login)): ?>
                                        <tr>
                                            <td><?php echo $log['id']; ?></td>
                                            <td><?php echo $log['namaLengkap'] . " (" . $log['username'] . ")"; ?></td>
                                            <td><?php echo ucfirst($log['role']); ?></td>
                                            <td><?php echo date('d/m/Y H:i:s', strtotime($log['login_time'])); ?></td>
                                            <td><?php echo $log['ip_address']; ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center">Belum ada data login</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- Logout Tab -->
                <div id="logout" class="tab-pane">
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User</th>
                                    <th>Role</th>
                                    <th>Waktu Logout</th>
                                    <th>IP Address</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (mysqli_num_rows($result_logout) > 0): ?>
                                    <?php while ($log = mysqli_fetch_assoc($result_logout)): ?>
                                        <tr>
                                            <td><?php echo $log['id']; ?></td>
                                            <td><?php echo $log['namaLengkap'] . " (" . $log['username'] . ")"; ?></td>
                                            <td><?php echo ucfirst($log['role']); ?></td>
                                            <td><?php echo date('d/m/Y H:i:s', strtotime($log['logout_time'])); ?></td>
                                            <td><?php echo $log['ip_address']; ?></td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center">Belum ada data logout</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="assets/js/script.js"></script>
    <script>
        // Tab functionality
        document.addEventListener('DOMContentLoaded', function() {
            const tabs = document.querySelectorAll('.tab');
            const tabPanes = document.querySelectorAll('.tab-pane');
            
            tabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    const tabId = this.getAttribute('data-tab');
                    
                    // Remove active class from all tabs and panes
                    tabs.forEach(t => t.classList.remove('active'));
                    tabPanes.forEach(p => p.classList.remove('active'));
                    
                    // Add active class to clicked tab and corresponding pane
                    this.classList.add('active');
                    document.getElementById(tabId).classList.add('active');
                });
            });
        });
    </script>
</body>
</html>
