<?php
// Tampilkan semua error
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'config.php';

echo "<h1>Buat Data Contoh</h1>";

// Buat data ruangan
$ruangan_data = array(
    array("Lab Komputer 1", 30, "Gedung A Lantai 1", "Teknik Informatika"),
    array("Lab Komputer 2", 30, "Gedung A Lantai 2", "Teknik Informatika"),
    array("Ruang Seminar", 50, "Gedung B Lantai 1", "Teknik Informatika"),
    array("Ruang Rapat", 20, "Gedung B Lantai 2", "Teknik Informatika")
);

foreach ($ruangan_data as $data) {
    $query = "INSERT INTO ruangan (namaRuangan, kapasitas, lokasi, prodi) 
              VALUES ('$data[0]', $data[1], '$data[2]', '$data[3]')";
    
    if (mysqli_query($conn, $query)) {
        echo "<p style='color: green;'>Ruangan '$data[0]' berhasil dibuat!</p>";
    } else {
        echo "<p style='color: red;'>Gagal membuat ruangan '$data[0]': " . mysqli_error($conn) . "</p>";
    }
}

// Buat data unit
$unit_data = array(
    array("LCD001", "Proyektor LCD", "Teknik Informatika"),
    array("LAPTOP001", "Laptop Presentasi", "Teknik Informatika"),
    array("SOUND001", "Sound System", "Teknik Informatika"),
    array("CAM001", "Kamera", "Teknik Informatika")
);

foreach ($unit_data as $data) {
    $query = "INSERT INTO unit (kodeUnit, namaUnit, prodi) 
              VALUES ('$data[0]', '$data[1]', '$data[2]')";
    
    if (mysqli_query($conn, $query)) {
        echo "<p style='color: green;'>Unit '$data[1]' berhasil dibuat!</p>";
    } else {
        echo "<p style='color: red;'>Gagal membuat unit '$data[1]': " . mysqli_error($conn) . "</p>";
    }
}

// Buat data mahasiswa
$mahasiswa_data = array(
    array("mahasiswa1", password_hash("mahasiswa123", PASSWORD_DEFAULT), "Mahasiswa Satu", "mahasiswa1@example.com", "MHS001", "mahasiswa", "Teknik Informatika"),
    array("mahasiswa2", password_hash("mahasiswa123", PASSWORD_DEFAULT), "Mahasiswa Dua", "mahasiswa2@example.com", "MHS002", "mahasiswa", "Teknik Informatika")
);

foreach ($mahasiswa_data as $data) {
    $query = "INSERT INTO mahasiswa (username, password, namaLengkap, email, nim, role, prodi) 
              VALUES ('$data[0]', '$data[1]', '$data[2]', '$data[3]', '$data[4]', '$data[5]', '$data[6]')";
    
    if (mysqli_query($conn, $query)) {
        echo "<p style='color: green;'>Mahasiswa '$data[2]' berhasil dibuat!</p>";
    } else {
        echo "<p style='color: red;'>Gagal membuat mahasiswa '$data[2]': " . mysqli_error($conn) . "</p>";
    }
}

echo "<p><a href='index.php'>Kembali ke Halaman Utama</a></p>";
?>