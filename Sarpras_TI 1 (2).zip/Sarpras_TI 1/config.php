<?php
// Tampilkan semua error
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Konfigurasi koneksi database
$host = "localhost";
$username = "root";
$password = "";
$database = "sarpras_ti";

// Membuat koneksi
$conn = mysqli_connect($host, $username, $password, $database);

// Cek koneksi
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Set timezone
date_default_timezone_set('Asia/Jakarta');

// Start session
session_start();

// Fungsi untuk menampilkan error
function showError($message) {
    echo "<div style='color: red; padding: 10px; border: 1px solid red; margin: 10px;'>Error: $message</div>";
}

// Fungsi untuk menampilkan pesan sukses
function showSuccess($message) {
    echo "<div style='color: green; padding: 10px; border: 1px solid green; margin: 10px;'>Success: $message</div>";
}

// Fungsi untuk membersihkan input
function cleanInput($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return mysqli_real_escape_string($conn, $data);
}
?>