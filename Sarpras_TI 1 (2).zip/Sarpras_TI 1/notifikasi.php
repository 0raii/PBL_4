<?php
include 'config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

// Ambil data user
$user_id = $_SESSION['id'];
$query = "SELECT * FROM mahasiswa WHERE id=$user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

// Ambil data dosen/staff jika role-nya dosen/staff
if ($user['role'] == 'dosen') {
    $query_dosen = "SELECT * FROM dosen WHERE idMahasiswa=$user_id";
    $result_dosen = mysqli_query($conn, $query_dosen);
    $dosen = mysqli_fetch_assoc($result_dosen);
    $user_id_number = $dosen['nipDosen'];
    $user_type = "Dosen";
    $user_icon = "fas fa-user-tie";
} elseif ($user['role'] == 'staff') {
    $query_staff = "SELECT * FROM staff WHERE idMahasiswa=$user_id";
    $result_staff = mysqli_query($conn, $query_staff);
    $staff = mysqli_fetch_assoc($result_staff);
    $user_id_number = $staff['nipStaff'];
    $user_type = "Staff";
    $user_icon = "fas fa-user-hard-hat";
} else { // mahasiswa
    $user_id_number = $user['nim'];
    $user_type = "Mahasiswa";
    $user_icon = "fas fa-user-graduate";
}

// Ambil data notifikasi
$query_notifikasi = "SELECT n.*, p.tanggalPinjam, p.jamMulai, p.jamSelesai, r.namaRuangan, u.namaUnit 
                    FROM notifikasi n 
                    JOIN peminjaman p ON n.idPeminjaman = p.id 
                    LEFT JOIN ruangan r ON p.idRuangan = r.id 
                    LEFT JOIN unit u ON p.idUnit = u.id 
                    WHERE p.idMahasiswa = $user_id 
                    ORDER BY n.created_at DESC";
$notifikasi = mysqli_query($conn, $query_notifikasi);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifikasi - Sistem Peminjaman Sarpras</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>Sarpras TI</h2>
            </div>
            
            <div class="sidebar-user">
                <div class="user-avatar">
                    <i class="<?php echo $user_icon; ?>"></i>
                </div>
                <div class="user-info">
                    <h3><?php echo $user['namaLengkap']; ?></h3>
                    <p><?php echo $user_type; ?></p>
                    <p class="user-nip"><?php echo $user_id_number; ?></p>
                </div>
            </div>
            
            <ul class="sidebar-menu">
                <?php if ($user['role'] == 'admin'): ?>
                    <li><a href="dashboard admin.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <?php elseif ($user['role'] == 'dosen' || $user['role'] == 'staff'): ?>
                    <li><a href="dashboard dosen.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <?php else: ?>
                    <li><a href="dashboard users.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <?php endif; ?>
                <li><a href="peminjaman.php"><i class="fas fa-plus-circle"></i> Ajukan Peminjaman</a></li>
                <li><a href="riwayat.php"><i class="fas fa-history"></i> Riwayat Peminjaman</a></li>
                <li class="active"><a href="notifikasi.php"><i class="fas fa-bell"></i> Notifikasi</a></li>
                <li><a href="process/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Notifikasi</h1>
                <div class="header-info">
                    <span><?php echo date('d F Y'); ?></span>
                </div>
            </div>
            
            <?php if (mysqli_num_rows($notifikasi) > 0): ?>
                <div class="notification-list">
                    <?php while ($n = mysqli_fetch_assoc($notifikasi)): ?>
                        <div class="notification-item">
                            <div class="notification-icon">
                                <i class="fas fa-info-circle"></i>
                            </div>
                            <div class="notification-content">
                                <p><?php echo $n['pesan']; ?></p>
                                <div class="notification-meta">
                                    <span class="notification-time"><?php echo date('d/m/Y H:i', strtotime($n['created_at'])); ?></span>
                                    <span class="notification-peminjaman">
                                        Peminjaman #<?php echo $n['idPeminjaman']; ?> - 
                                        <?php 
                                        if ($n['namaRuangan']) {
                                            echo $n['namaRuangan'];
                                        } elseif ($n['namaUnit']) {
                                            echo $n['namaUnit'];
                                        }
                                        ?>
                                    </span>
                                </div>
                            </div>
                            <div class="notification-status">
                                <span class="status-badge status-<?php echo $n['status']; ?>">
                                    <?php echo ucfirst($n['status']); ?>
                                </span>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-bell-slash"></i>
                    <p>Belum ada notifikasi</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="assets/js/script.js"></script>
</body>
</html>