<?php
include 'config.php';

// Cek apakah user sudah login dan role-nya dosen atau staff
if (!isset($_SESSION['id']) || ($_SESSION['role'] != 'dosen' && $_SESSION['role'] != 'staff')) {
    header("Location: index.php");
    exit();
}

// Ambil data user
$user_id = $_SESSION['id'];
$query = "SELECT * FROM mahasiswa WHERE id=$user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

// Ambil data dosen/staff
if ($user['role'] == 'dosen') {
    $query_dosen = "SELECT * FROM dosen WHERE idMahasiswa=$user_id";
    $result_dosen = mysqli_query($conn, $query_dosen);
    $dosen = mysqli_fetch_assoc($result_dosen);
    $user_id_number = $dosen['nipDosen'];
    $user_type = "Dosen";
    $user_icon = "fas fa-user-tie";
} else { // staff
    $query_staff = "SELECT * FROM staff WHERE idMahasiswa=$user_id";
    $result_staff = mysqli_query($conn, $query_staff);
    $staff = mysqli_fetch_assoc($result_staff);
    $user_id_number = $staff['nipStaff'];
    $user_type = "Staff";
    $user_icon = "fas fa-user-hard-hat";
}

// Ambil data peminjaman aktif
$query_peminjaman = "SELECT p.*, r.namaRuangan, u.namaUnit 
                    FROM peminjaman p 
                    LEFT JOIN ruangan r ON p.idRuangan = r.id 
                    LEFT JOIN unit u ON p.idUnit = u.id 
                    WHERE p.idMahasiswa = $user_id AND p.status IN ('pending', 'disetujui') 
                    ORDER BY p.created_at DESC";
$peminjaman_aktif = mysqli_query($conn, $query_peminjaman);

// Ambil notifikasi
$query_notifikasi = "SELECT n.*, p.tanggalPinjam, p.jamMulai, p.jamSelesai 
                    FROM notifikasi n 
                    JOIN peminjaman p ON n.idPeminjaman = p.id 
                    WHERE p.idMahasiswa = $user_id 
                    ORDER BY n.created_at DESC LIMIT 5";
$notifikasi = mysqli_query($conn, $query_notifikasi);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard <?php echo $user_type; ?> - Sistem Peminjaman Sarpras</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>Sarpras TI</h2>
            </div>
            
            <div class="sidebar-user">
                <div class="user-avatar">
                    <i class="<?php echo $user_icon; ?>"></i>
                </div>
                <div class="user-info">
                    <h3><?php echo $user['namaLengkap']; ?></h3>
                    <p><?php echo $user_type; ?></p>
                    <p class="user-nip"><?php echo $user_id_number; ?></p>
                </div>
            </div>
            
            <ul class="sidebar-menu">
                <li class="active"><a href="dosen_dashboard.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <li><a href="peminjaman.php"><i class="fas fa-plus-circle"></i> Ajukan Peminjaman</a></li>
                <li><a href="riwayat.php"><i class="fas fa-history"></i> Riwayat Peminjaman</a></li>
                <li><a href="notifikasi.php"><i class="fas fa-bell"></i> Notifikasi</a></li>
                <li><a href="proses/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Dashboard <?php echo $user_type; ?></h1>
                <div class="header-info">
                    <span><?php echo date('d F Y'); ?></span>
                </div>
            </div>
            
            <!-- Cards -->
            <div class="dashboard-cards">
                <div class="card">
                    <div class="card-icon bg-primary">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <div class="card-content">
                        <h3>Peminjaman Aktif</h3>
                        <p class="card-value"><?php echo mysqli_num_rows($peminjaman_aktif); ?></p>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-icon bg-success">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="card-content">
                        <h3>Disetujui</h3>
                        <p class="card-value">
                            <?php 
                            $query_disetujui = "SELECT COUNT(*) as total FROM peminjaman WHERE idMahasiswa = $user_id AND status = 'disetujui'";
                            $result_disetujui = mysqli_query($conn, $query_disetujui);
                            $data_disetujui = mysqli_fetch_assoc($result_disetujui);
                            echo $data_disetujui['total'];
                            ?>
                        </p>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-icon bg-warning">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="card-content">
                        <h3>Menunggu Persetujuan</h3>
                        <p class="card-value">
                            <?php 
                            $query_pending = "SELECT COUNT(*) as total FROM peminjaman WHERE idMahasiswa = $user_id AND status = 'pending'";
                            $result_pending = mysqli_query($conn, $query_pending);
                            $data_pending = mysqli_fetch_assoc($result_pending);
                            echo $data_pending['total'];
                            ?>
                        </p>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-icon bg-info">
                        <i class="fas fa-bell"></i>
                    </div>
                    <div class="card-content">
                        <h3>Notifikasi</h3>
                        <p class="card-value"><?php echo mysqli_num_rows($notifikasi); ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Peminjaman Aktif -->
            <div class="recent-peminjaman">
                <h2>Peminjaman Aktif</h2>
                
                <?php if (mysqli_num_rows($peminjaman_aktif) > 0): ?>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Tanggal</th>
                                    <th>Jam</th>
                                    <th>Ruangan/Unit</th>
                                    <th>Keperluan</th>
                                    <th>Status</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($p = mysqli_fetch_assoc($peminjaman_aktif)): ?>
                                    <tr>
                                        <td>#<?php echo $p['id']; ?></td>
                                        <td><?php echo date('d/m/Y', strtotime($p['tanggalPinjam'])); ?></td>
                                        <td><?php echo date('H:i', strtotime($p['jamMulai'])) . ' - ' . date('H:i', strtotime($p['jamSelesai'])); ?></td>
                                        <td>
                                            <?php 
                                            if ($p['idRuangan']) {
                                                echo $p['namaRuangan'];
                                            } elseif ($p['idUnit']) {
                                                echo $p['namaUnit'];
                                            } else {
                                                echo '-';
                                            }
                                            ?>
                                        </td>
                                        <td><?php echo substr($p['keperluan'], 0, 30) . '...'; ?></td>
                                        <td>
                                            <span class="status-badge status-<?php echo $p['status']; ?>">
                                                <?php echo ucfirst($p['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if ($p['status'] == 'disetujui'): ?>
                                                <a href="pengembalian.php?id=<?php echo $p['id']; ?>" class="btn btn-sm btn-success">Kembalikan</a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-calendar-times"></i>
                        <p>Belum ada peminjaman aktif</p>
                        <a href="peminjaman.php" class="btn btn-primary">Ajukan Peminjaman</a>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Notifikasi Terbaru -->
            <div class="recent-notifikasi">
                <h2>Notifikasi Terbaru</h2>
                
                <?php if (mysqli_num_rows($notifikasi) > 0): ?>
                    <div class="notification-list">
                        <?php while ($n = mysqli_fetch_assoc($notifikasi)): ?>
                            <div class="notification-item">
                                <div class="notification-icon">
                                    <i class="fas fa-info-circle"></i>
                                </div>
                                <div class="notification-content">
                                    <p><?php echo $n['pesan']; ?></p>
                                    <span class="notification-time"><?php echo date('d/m/Y H:i', strtotime($n['created_at'])); ?></span>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                    <div class="text-center mt-3">
                        <a href="notifikasi.php" class="btn btn-outline">Lihat Semua Notifikasi</a>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-bell-slash"></i>
                        <p>Belum ada notifikasi</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script src="assets/js/script.js"></script>
</body>
</html>