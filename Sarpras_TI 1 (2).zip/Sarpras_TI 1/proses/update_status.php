<?php
include '../config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['id'])) {
    header("Location: ../index.php");
    exit();
}

if (isset($_GET['id']) && isset($_GET['status'])) {
    $id = $_GET['id'];
    $status = $_GET['status'];
    
    // Update status peminjaman
    $query = "UPDATE peminjaman SET status='$status' WHERE id=$id";
    
    if (mysqli_query($conn, $query)) {
        // Jika status disetujui, update status ruangan/unit
        if ($status == 'disetujui') {
            // Get peminjaman data
            $query_peminjaman = "SELECT * FROM peminjaman WHERE id=$id";
            $result_peminjaman = mysqli_query($conn, $query_peminjaman);
            $peminjaman = mysqli_fetch_assoc($result_peminjaman);
            
            if ($peminjaman['idRuangan']) {
                $query_ruangan = "UPDATE ruangan SET status='dipinjam' WHERE id=" . $peminjaman['idRuangan'];
                mysqli_query($conn, $query_ruangan);
            } elseif ($peminjaman['idUnit']) {
                $query_unit = "UPDATE unit SET status='dipinjam' WHERE id=" . $peminjaman['idUnit'];
                mysqli_query($conn, $query_unit);
            }
        }
        
        // Jika status selesai atau batal, update status ruangan/unit menjadi tersedia
        if ($status == 'selesai' || $status == 'batal') {
            // Get peminjaman data
            $query_peminjaman = "SELECT * FROM peminjaman WHERE id=$id";
            $result_peminjaman = mysqli_query($conn, $query_peminjaman);
            $peminjaman = mysqli_fetch_assoc($result_peminjaman);
            
            if ($peminjaman['idRuangan']) {
                $query_ruangan = "UPDATE ruangan SET status='tersedia' WHERE id=" . $peminjaman['idRuangan'];
                mysqli_query($conn, $query_ruangan);
            } elseif ($peminjaman['idUnit']) {
                $query_unit = "UPDATE unit SET status='tersedia' WHERE id=" . $peminjaman['idUnit'];
                mysqli_query($conn, $query_unit);
            }
        }
        
        $_SESSION['success'] = "Status peminjaman berhasil diperbarui!";
        
        // Redirect based on user role
        if ($_SESSION['role'] == 'admin') {
            header("Location: ../dashboard admin.php");
        } elseif ($_SESSION['role'] == 'dosen' || $_SESSION['role'] == 'staff') {
            header("Location: ../dashboard dosen.php");
        } else { // mahasiswa
            header("Location: ../dashboard users.php");
        }
        exit();
    } else {
        $_SESSION['error'] = "Gagal memperbarui status: " . mysqli_error($conn);
        
        // Redirect based on user role
        if ($_SESSION['role'] == 'admin') {
            header("Location: ../admin_dashboard.php");
        } elseif ($_SESSION['role'] == 'dosen' || $_SESSION['role'] == 'staff') {
            header("Location: ../dosen_dashboard.php");
        } else { // mahasiswa
            header("Location: ../dashboard.php");
        }
        exit();
    }
} else {
    // Redirect based on user role
    if ($_SESSION['role'] == 'admin') {
        header("Location: ../admin_dashboard.php");
    } elseif ($_SESSION['role'] == 'dosen' || $_SESSION['role'] == 'staff') {
        header("Location: ../dosen_dashboard.php");
    } else { // mahasiswa
        header("Location: ../dashboard.php");
    }
    exit();
}
?>