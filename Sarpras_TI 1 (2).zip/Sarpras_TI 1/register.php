<?php
// Definisikan konstanta untuk menandai aplikasi telah dimulai
define('APP_STARTED', true);

// Tampilkan semua error
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'config.php';

// Cek koneksi database
if (!$conn) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Jika sudah login, redirect ke dashboard
if (isset($_SESSION['id'])) {
    header("Location: dashboard users.php");
     header("Location: dashboard admin.php");
      header("Location: dashboard dosen.php");
    exit();
}

// Proses registrasi
if (isset($_POST['register'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirmPassword = mysqli_real_escape_string($conn, $_POST['confirmPassword']);
    $namaLengkap = mysqli_real_escape_string($conn, $_POST['namaLengkap']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $nim = mysqli_real_escape_string($conn, $_POST['nim']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);
    $prodi = mysqli_real_escape_string($conn, $_POST['prodi']);
    
    // Validasi password
    if ($password != $confirmPassword) {
        $error = "Password dan konfirmasi password tidak cocok!";
    } else {
        // Cek apakah username sudah ada
        $query = "SELECT * FROM mahasiswa WHERE username='$username'";
        $result = mysqli_query($conn, $query);
        
        if (mysqli_num_rows($result) > 0) {
            $error = "Username sudah digunakan!";
        } else {
            // Cek apakah email sudah ada
            $query = "SELECT * FROM mahasiswa WHERE email='$email'";
            $result = mysqli_query($conn, $query);
            
            if (mysqli_num_rows($result) > 0) {
                $error = "Email sudah digunakan!";
            } else {
                // Cek apakah NIM sudah ada
                $query = "SELECT * FROM mahasiswa WHERE nim='$nim'";
                $result = mysqli_query($conn, $query);
                
                if (mysqli_num_rows($result) > 0) {
                    $error = "NIM sudah digunakan!";
                } else {
                    // Hash password
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    
                    // Insert user baru
                    $query = "INSERT INTO mahasiswa (username, password, namaLengkap, email, nim, role, prodi) 
                              VALUES ('$username', '$hashedPassword', '$namaLengkap', '$email', '$nim', '$role', '$prodi')";
                    
                    if (mysqli_query($conn, $query)) {
                        $success = "Registrasi berhasil! Silakan login dengan akun Anda.";
                        
                        // Jika role dosen atau staff, buat record di tabel dosen/staff
                        if ($role == 'dosen') {
                            $userId = mysqli_insert_id($conn);
                            $nipDosen = "DOS" . date('Ym') . sprintf("%03d", $userId);
                            
                            $query = "INSERT INTO dosen (idMahasiswa, nipDosen, email, namaLengkap, noHp) 
                                      VALUES ($userId, '$nipDosen', '$email', '$namaLengkap', '-')";
                            mysqli_query($conn, $query);
                        } elseif ($role == 'staff') {
                            $userId = mysqli_insert_id($conn);
                            $nipStaff = "STF" . date('Ym') . sprintf("%03d", $userId);
                            
                            $query = "INSERT INTO staff (idMahasiswa, nipStaff, email, namaLengkap, noHp) 
                                      VALUES ($userId, '$nipStaff', '$email', '$namaLengkap', '-')";
                            mysqli_query($conn, $query);
                        }
                    } else {
                        $error = "Registrasi gagal: " . mysqli_error($conn);
                    }
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Peminjaman Sarpras - Registrasi</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="auth-container">
        <div class="auth-box">
            <div class="auth-header">
                <h1>Registrasi Akun Baru</h1>
                <p>Isi formulir di bawah untuk membuat akun</p>
            </div>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <form action="register.php" method="post">
                <div class="form-row">
                    <div class="form-group">
                        <label for="namaLengkap">Nama Lengkap</label>
                        <input type="text" id="namaLengkap" name="namaLengkap" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="nim">NIM/NIP</label>
                        <input type="text" id="nim" name="nim" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="role">Role</label>
                        <select id="role" name="role" required>
                            <option value="">Pilih Role</option>
                            <option value="mahasiswa">Mahasiswa</option>
                            <option value="dosen">Dosen</option>
                            <option value="staff">Staff</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="prodi">Program Studi</label>
                    <select id="prodi" name="prodi" required>
                        <option value="">Pilih Program Studi</option>
                        <option value="Teknologi Informasi">Teknik Informatika</option>
                    </select>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="confirmPassword">Konfirmasi Password</label>
                    <input type="password" id="confirmPassword" name="confirmPassword" required>
                </div>
                
                <div class="form-group">
                    <button type="submit" name="register" class="btn btn-primary btn-block">Daftar</button>
                </div>
            </form>
            
            <div class="auth-footer">
                <p>Sudah punya akun? <a href="index.php">Login di sini</a></p>
            </div>
        </div>
    </div>
    
    <script>
        // Validasi konfirmasi password
        document.getElementById('confirmPassword').addEventListener('input', function() {
            const password = document.getElementById('password').value;
            const confirmPassword = this.value;
            
            if (password !== confirmPassword) {
                this.setCustomValidity('Password tidak cocok!');
            } else {
                this.setCustomValidity('');
            }
        });
        
        // Validasi format NIM/NIP
        document.getElementById('nim').addEventListener('input', function() {
            this.value = this.value.toUpperCase();
        });
    </script>
</body>
</html>