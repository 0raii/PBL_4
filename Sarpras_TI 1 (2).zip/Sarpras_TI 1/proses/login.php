<?php
// Tampilkan semua error
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../config.php'; // config.php sudah melakukan session_start() dan membuat $conn

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    // Ambil input (username bersihkan untuk query)
    $username = trim($_POST['username']);
    $password = $_POST['password']; // jangan escape password sebelum password_verify

    // Prepared statement untuk ambil user berdasarkan username
    $stmt = mysqli_prepare($conn, "SELECT id, username, password, role, namaLengkap FROM mahasiswa WHERE username = ?");
    if (!$stmt) {
        $_SESSION['error'] = "Query error: " . mysqli_error($conn);
        header("Location: ../index.php");
        exit();
    }
    mysqli_stmt_bind_param($stmt, 's', $username);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    if (mysqli_stmt_num_rows($stmt) == 1) {
        mysqli_stmt_bind_result($stmt, $id, $uname, $hashed_password, $role, $namaLengkap);
        mysqli_stmt_fetch($stmt);

        // Verifikasi password
        if (password_verify($password, $hashed_password)) {
            // Set session variables
            $_SESSION['id'] = $id;
            $_SESSION['username'] = $uname;
            $_SESSION['role'] = $role;
            $_SESSION['namaLengkap'] = $namaLengkap;

            // Ambil IP
            $ip_address = $_SERVER['REMOTE_ADDR'];

            // Insert ke tabel "login" (sesuai struktur DB Anda)
            $stmt2 = mysqli_prepare($conn, "INSERT INTO `login` (user_id, ip_address) VALUES (?, ?)");
            if ($stmt2) {
                mysqli_stmt_bind_param($stmt2, 'is', $id, $ip_address);
                mysqli_stmt_execute($stmt2);
                mysqli_stmt_close($stmt2);
            }

            // Redirect sesuai role (saya biarkan nama file seperti versi Anda supaya tidak memecah link lain)
            if ($role == 'admin') {
                header("Location: ../dashboard admin.php");
            } elseif ($role == 'dosen' || $role == 'staff') {
                header("Location: ../dashboard dosen.php");
            } else {
                header("Location: ../dashboard users.php");
            }
            exit();
        } else {
            $_SESSION['error'] = "Password salah!";
            header("Location: ../index.php");
            exit();
        }
    } else {
        $_SESSION['error'] = "Username tidak ditemukan!";
        header("Location: ../index.php");
        exit();
    }

    mysqli_stmt_close($stmt);
} else {
    header("Location: ../index.php");
    exit();
}
?>
