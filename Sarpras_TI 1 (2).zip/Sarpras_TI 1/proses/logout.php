<?php
// Tampilkan semua error
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../config.php'; // config.php sudah session_start() dan $conn

if (isset($_SESSION['id'])) {
    $user_id = $_SESSION['id'];
    $ip_address = $_SERVER['REMOTE_ADDR'];

    // Simpan log logout
    $stmt = mysqli_prepare($conn, "INSERT INTO `logout` (user_id, ip_address) VALUES (?, ?)");
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'is', $user_id, $ip_address);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }

    // Hapus session
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
}

// Tutup koneksi database
if ($conn) {
    mysqli_close($conn);
}

// Redirect ke halaman login
header("Location: ../index.php");
exit();
?>
