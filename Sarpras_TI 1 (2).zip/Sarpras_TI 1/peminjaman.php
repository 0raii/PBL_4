<?php
// Definisikan konstanta untuk menandai aplikasi telah dimulai
define('APP_STARTED', true);

// Tampilkan semua error
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

// Ambil data user
$user_id = $_SESSION['id'];
$query = "SELECT * FROM mahasiswa WHERE id=$user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

// Ambil data dosen/staff jika role-nya dosen/staff
if ($user['role'] == 'dosen') {
    $query_dosen = "SELECT * FROM dosen WHERE idMahasiswa=$user_id";
    $result_dosen = mysqli_query($conn, $query_dosen);
    $dosen = mysqli_fetch_assoc($result_dosen);
    $user_id_number = $dosen['nipDosen'];
    $user_type = "Dosen";
    $user_icon = "fas fa-user-tie";
} elseif ($user['role'] == 'staff') {
    $query_staff = "SELECT * FROM staff WHERE idMahasiswa=$user_id";
    $result_staff = mysqli_query($conn, $query_staff);
    $staff = mysqli_fetch_assoc($result_staff);
    $user_id_number = $staff['nipStaff'];
    $user_type = "Staff";
    $user_icon = "fas fa-user-hard-hat";
} else { // mahasiswa
    $user_id_number = $user['nim'];
    $user_type = "Mahasiswa";
    $user_icon = "fas fa-user-graduate";
}

// Ambil data ruangan
$query_ruangan = "SELECT * FROM ruangan WHERE status='tersedia'";
$ruangan = mysqli_query($conn, $query_ruangan);

// Ambil data unit
$query_unit = "SELECT * FROM unit WHERE status='tersedia'";
$unit = mysqli_query($conn, $query_unit);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajukan Peminjaman - Sistem Peminjaman Sarpras</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>Sarpras TI</h2>
            </div>
            
            <div class="sidebar-user">
                <div class="user-avatar">
                    <i class="<?php echo $user_icon; ?>"></i>
                </div>
                <div class="user-info">
                    <h3><?php echo $user['namaLengkap']; ?></h3>
                    <p><?php echo $user_type; ?></p>
                    <p class="user-nip"><?php echo $user_id_number; ?></p>
                </div>
            </div>
            
            <ul class="sidebar-menu">
                <?php if ($user['role'] == 'admin'): ?>
                    <li><a href="dashboard admin.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <?php elseif ($user['role'] == 'dosen' || $user['role'] == 'staff'): ?>
                    <li><a href="dashboard dosen.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <?php else: ?>
                    <li><a href="dashboard users.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <?php endif; ?>
                <li class="active"><a href="peminjaman.php"><i class="fas fa-plus-circle"></i> Ajukan Peminjaman</a></li>
                <li><a href="riwayat.php"><i class="fas fa-history"></i> Riwayat Peminjaman</a></li>
                <li><a href="notifikasi.php"><i class="fas fa-bell"></i> Notifikasi</a></li>
                <li><a href="proses/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Ajukan Peminjaman</h1>
                <div class="header-info">
                    <span><?php echo date('d F Y'); ?></span>
                </div>
            </div>
            
            <div class="form-container">
                <form action="proses/tambah_peminjaman.php" method="post" id="formPeminjaman">
                    <div class="form-section">
                        <h2>Informasi Peminjaman</h2>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="jenis">Jenis Peminjaman</label>
                                <select id="jenis" name="jenis" required>
                                    <option value="">Pilih Jenis</option>
                                    <option value="ruangan">Ruangan</option>
                                    <option value="unit">Unit/Alat</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label for="tanggalPinjam">Tanggal Pinjam</label>
                                <input type="date" id="tanggalPinjam" name="tanggalPinjam" required>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="jamMulai">Jam Mulai</label>
                                <input type="time" id="jamMulai" name="jamMulai" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="jamSelesai">Jam Selesai</label>
                                <input type="time" id="jamSelesai" name="jamSelesai" required>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="keperluan">Keperluan</label>
                            <textarea id="keperluan" name="keperluan" rows="3" required></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label for="prioritas">Prioritas</label>
                            <select id="prioritas" name="prioritas" required>
                                <option value="rendah">Rendah</option>
                                <option value="sedang" selected>Sedang</option>
                                <option value="tinggi">Tinggi</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-section" id="ruanganSection" style="display: none;">
                        <h2>Pilih Ruangan</h2>
                        
                        <div class="form-group">
                            <label for="ruangan">Ruangan</label>
                            <select id="ruangan" name="idRuangan">
                                <option value="">Pilih Ruangan</option>
                                
                                <!-- Gedung Teknologi Informasi - Nadiem Makarim -->
                                <optgroup label="Gedung Teknologi Informasi - Nadiem Makarim">
                                    <!-- Lantai 3 -->
                                    <optgroup label="&nbsp;&nbsp;Lantai 3">
                                        <option value="1">Lab Steve Jobs</option>
                                        <option value="2">Lab Linus Torvalds</option>
                                        <option value="3">Lab Bill Gates</option>
                                        <option value="1">Lab Kenneth Thompson</option>
                                    </optgroup>
                                    
                                    <!-- Lantai 2 -->
                                    <optgroup label="&nbsp;&nbsp;Lantai 2">
                                        <option value="4">Lab Guido Van Rossum (Python)</option>
                                        <option value="5">Lab Dennis Ritchie (C++)</option>
                                        <option value="6">Lab Rasmus Lerdorf (PHP)</option>
                                    </optgroup>
                                    
                                    <!-- Lantai 1 -->
                                    <optgroup label="&nbsp;&nbsp;Lantai 1">
                                        <option value="7">Aula TI</option>
                                    </optgroup>
                                </optgroup>
                                
                                <!-- Gedung Ardiansyah 1 -->
                                <optgroup label="Gedung Ardiansyah 1">
                                    <!-- Lantai 1 -->
                                    <optgroup label="&nbsp;&nbsp;Lantai 1">
                                        <option value="8">Lab A</option>
                                    </optgroup>
                                    
                                    <!-- Lantai 2 -->
                                    <optgroup label="&nbsp;&nbsp;Lantai 2">
                                        <option value="9">Lab B</option>
                                        <option value="10">Lab C</option>
                                        <option value="11">Lab Komputer Jaringan</option>
                                    </optgroup>
                                </optgroup>
                                
                                <!-- Gedung Ardiansyah 2 -->
                                <optgroup label="Gedung Ardiansyah 2">
                                    <!-- Lantai 1 -->
                                    <optgroup label="&nbsp;&nbsp;Lantai 1">
                                        <option value="12">Ruang Kelas 3 - EX Hima</option>
                                    </optgroup>
                                    
                                    <!-- Lantai 2 -->
                                    <optgroup label="&nbsp;&nbsp;Lantai 2">
                                        <option value="13">Lab HTML</option>
                                        <option value="14">Lab C++</option>
                                        <option value="15">Lab Python</option>
                                        <option value="16">Lab PHP</option>
                                    </optgroup>
                                </optgroup>
                            </select>
                        </div>
                        
                        <div class="ruangan-info" id="ruanganInfo" style="display: none;">
                            <h3>Informasi Ruangan</h3>
                            <div class="info-grid">
                                <div class="info-item">
                                    <span class="info-label">Nama:</span>
                                    <span class="info-value" id="infoNamaRuangan">-</span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Kapasitas:</span>
                                    <span class="info-value" id="infoKapasitas">-</span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Lokasi:</span>
                                    <span class="info-value" id="infoLokasi">-</span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Prodi:</span>
                                    <span class="info-value" id="infoProdi">-</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-section" id="unitSection" style="display: none;">
                        <h2>Pilih Unit/Alat</h2>
                        
                        <div class="form-group">
                            <label for="unit">Unit/Alat</label>
                            <select id="unit" name="idUnit">
                                <option value="">Pilih Unit/Alat</option>
                                
                                <!-- Proyektor -->
                                <optgroup label="Proyektor">
                                    <option value="1">Proyektor EPSON EB-X41 (Dengan Kabel HDMI)</option>
                                    <option value="2">Proyektor EPSON EB-U05 (Dengan Kabel VGA)</option>
                                    <option value="3">Proyektor EPSON EB-X06 (Dengan Kabel HDMI & VGA)</option>
                                    <option value="4">Proyektor BenQ MX525 (Dengan Kabel HDMI)</option>
                                    <option value="5">Proyektor BenQ MS524 (Dengan Kabel VGA)</option>
                                </optgroup>
                                
                                <!-- Laptop -->
                                <optgroup label="Laptop">
                                    <option value="6">Laptop ASUS A407 (Dengan Charger)</option>
                                    <option value="7">Laptop ASUS X441BA (Dengan Charger)</option>
                                    <option value="8">Laptop ASUS P2540UA (Dengan Charger & Mouse)</option>
                                    <option value="9">Laptop Acer Aspire 3 (Dengan Charger)</option>
                                    <option value="10">Laptop Lenovo IdeaPad (Dengan Charger)</option>
                                </optgroup>
                                
                                <!-- Sound System -->
                                <optgroup label="Sound System">
                                    <option value="11">Speaker Aktif Polytron (Dengan Kabel RCA)</option>
                                    <option value="12">Speaker Aktif Simbadda (Dengan Kabel Jack 3.5mm)</option>
                                    <option value="13">Mic Wireless (Dengan Receiver & Kabel Power)</option>
                                    <option value="14">Mic Kabel (Dengan Stand)</option>
                                </optgroup>
                                
                                <!-- Kamera -->
                                <optgroup label="Kamera">
                                    <option value="15">Kamera DSLR Canon (Dengan Lensa 18-55mm & Memory Card)</option>
                                    <option value="16">Kamera DSLR Nikon (Dengan Lensa 18-55mm & Memory Card)</option>
                                    <option value="17">Kamera Mirrorless Sony (Dengan Lensa 16-50mm & Memory Card)</option>
                                    <option value="18">Tripod (Dengan Tas)</option>
                                </optgroup>
                                
                                <!-- Lainnya -->
                                <optgroup label="Lainnya">
                                    <option value="19">Interactive Board (Dengan Stylus & Kabel USB)</option>
                                    <option value="20">Document Camera (Dengan Kabel USB)</option>
                                    <option value="21">Screen Tabung (Dengan Kabel Power & VGA)</option>
                                    <option value="22">TV LED 32" (Dengan Kabel Power & HDMI)</option>
                                </optgroup>
                            </select>
                        </div>
                        
                        <div class="unit-info" id="unitInfo" style="display: none;">
                            <h3>Informasi Unit</h3>
                            <div class="info-grid">
                                <div class="info-item">
                                    <span class="info-label">Nama:</span>
                                    <span class="info-value" id="infoNamaUnit">-</span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Kode:</span>
                                    <span class="info-value" id="infoKodeUnit">-</span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Prodi:</span>
                                    <span class="info-value" id="infoProdiUnit">-</span>
                                </div>
                                <div class="info-item">
                                    <span class="info-label">Kelengkapan:</span>
                                    <span class="info-value" id="infoKelengkapanUnit">-</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Ajukan Peminjaman</button>
                        <a href="<?php 
                            if ($user['role'] == 'admin') {
                                echo 'dashboard admin.php';
                            } elseif ($user['role'] == 'dosen' || $user['role'] == 'staff') {
                                echo 'dashboard dosen.php';
                            } else {
                                echo 'dashboard users.php';
                            }
                        ?>" class="btn btn-outline">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="assets/js/script.js"></script>
    <script>
        // Data ruangan
        const dataRuangan = [
            {id: 1, namaRuangan: "Lab Steve Jobs", kapasitas: 30, lokasi: "Gedung Teknologi Informasi - Nadiem Makarim Lantai 3", prodi: "Teknologi Informasi"},
            {id: 2, namaRuangan: "Lab Linus Torvalds", kapasitas: 30, lokasi: "Gedung Teknologi Informasi - Nadiem Makarim Lantai 3", prodi: "Teknologi Informasi"},
            {id: 3, namaRuangan: "Lab Bill Gates", kapasitas: 30, lokasi: "Gedung Teknologi Informasi - Nadiem Makarim Lantai 3", prodi: "Teknologi Informasi"},
            {id: 4, namaRuangan: "Lab Guido Van Rossum (Python)", kapasitas: 30, lokasi: "Gedung Teknologi Informasi - Nadiem Makarim Lantai 2", prodi: "Teknologi Informasi"},
            {id: 5, namaRuangan: "Lab Dennis Ritchie (C++)", kapasitas: 30, lokasi: "Gedung Teknologi Informasi - Nadiem Makarim Lantai 2", prodi: "Teknologi Informasi"},
            {id: 6, namaRuangan: "Lab Rasmus Lerdorf (PHP)", kapasitas: 30, lokasi: "Gedung Teknologi Informasi - Nadiem Makarim Lantai 2", prodi: "Teknologi Informasi"},
            {id: 7, namaRuangan: "Aula TI", kapasitas: 100, lokasi: "Gedung Teknologi Informasi - Nadiem Makarim Lantai 1", prodi: "Teknologi Informasi"},
            {id: 8, namaRuangan: "Lab A", kapasitas: 30, lokasi: "Gedung Ardiansyah 1 Lantai 1", prodi: "Teknologi Informasi"},
            {id: 9, namaRuangan: "Lab B", kapasitas: 30, lokasi: "Gedung Ardiansyah 1 Lantai 2", prodi: "Teknologi Informasi"},
            {id: 10, namaRuangan: "Lab C", kapasitas: 30, lokasi: "Gedung Ardiansyah 1 Lantai 2", prodi: "Teknologi Informasi"},
            {id: 11, namaRuangan: "Lab Komputer Jaringan", kapasitas: 30, lokasi: "Gedung Ardiansyah 1 Lantai 2", prodi: "Teknologi Informasi"},
            {id: 12, namaRuangan: "Ruang Kelas 3 - EX Hima", kapasitas: 40, lokasi: "Gedung Ardiansyah 2 Lantai 1", prodi: "Teknologi Informasi"},
            {id: 13, namaRuangan: "Lab HTML", kapasitas: 30, lokasi: "Gedung Ardiansyah 2 Lantai 2", prodi: "Teknologi Informasi"},
            {id: 14, namaRuangan: "Lab C++", kapasitas: 30, lokasi: "Gedung Ardiansyah 2 Lantai 2", prodi: "Teknologi Informasi"},
            {id: 15, namaRuangan: "Lab Python", kapasitas: 30, lokasi: "Gedung Ardiansyah 2 Lantai 2", prodi: "Teknologi Informasi"},
            {id: 16, namaRuangan: "Lab PHP", kapasitas: 30, lokasi: "Gedung Ardiansyah 2 Lantai 2", prodi: "Teknologi Informasi"}
        ];
        
        // Data unit
        const dataUnit = [
            {id: 1, kodeUnit: "PRJ001", namaUnit: "Proyektor EPSON EB-X41", prodi: "Teknologi Informasi", kelengkapan: "Dengan Kabel HDMI"},
            {id: 2, kodeUnit: "PRJ002", namaUnit: "Proyektor EPSON EB-U05", prodi: "Teknologi Informasi", kelengkapan: "Dengan Kabel VGA"},
            {id: 3, kodeUnit: "PRJ003", namaUnit: "Proyektor EPSON EB-X06", prodi: "Teknologi Informasi", kelengkapan: "Dengan Kabel HDMI & VGA"},
            {id: 4, kodeUnit: "PRJ004", namaUnit: "Proyektor BenQ MX525", prodi: "Teknologi Informasi", kelengkapan: "Dengan Kabel HDMI"},
            {id: 5, kodeUnit: "PRJ005", namaUnit: "Proyektor BenQ MS524", prodi: "Teknologi Informasi", kelengkapan: "Dengan Kabel VGA"},
            {id: 6, kodeUnit: "LAP001", namaUnit: "Laptop ASUS A407", prodi: "Teknologi Informasi", kelengkapan: "Dengan Charger"},
            {id: 7, kodeUnit: "LAP002", namaUnit: "Laptop ASUS X441BA", prodi: "Teknologi Informasi", kelengkapan: "Dengan Charger"},
            {id: 8, kodeUnit: "LAP003", namaUnit: "Laptop ASUS P2540UA", prodi: "Teknologi Informasi", kelengkapan: "Dengan Charger & Mouse"},
            {id: 9, kodeUnit: "LAP004", namaUnit: "Laptop Acer Aspire 3", prodi: "Teknologi Informasi", kelengkapan: "Dengan Charger"},
            {id: 10, kodeUnit: "LAP005", namaUnit: "Laptop Lenovo IdeaPad", prodi: "Teknologi Informasi", kelengkapan: "Dengan Charger"},
            {id: 11, kodeUnit: "SND001", namaUnit: "Speaker Aktif Polytron", prodi: "Teknologi Informasi", kelengkapan: "Dengan Kabel RCA"},
            {id: 12, kodeUnit: "SND002", namaUnit: "Speaker Aktif Simbadda", prodi: "Teknologi Informasi", kelengkapan: "Dengan Kabel Jack 3.5mm"},
            {id: 13, kodeUnit: "MIC001", namaUnit: "Mic Wireless", prodi: "Teknologi Informasi", kelengkapan: "Dengan Receiver & Kabel Power"},
            {id: 14, kodeUnit: "MIC002", namaUnit: "Mic Kabel", prodi: "Teknologi Informasi", kelengkapan: "Dengan Stand"},
            {id: 15, kodeUnit: "CAM001", namaUnit: "Kamera DSLR Canon", prodi: "Teknologi Informasi", kelengkapan: "Dengan Lensa 18-55mm & Memory Card"},
            {id: 16, kodeUnit: "CAM002", namaUnit: "Kamera DSLR Nikon", prodi: "Teknologi Informasi", kelengkapan: "Dengan Lensa 18-55mm & Memory Card"},
            {id: 17, kodeUnit: "CAM003", namaUnit: "Kamera Mirrorless Sony", prodi: "Teknologi Informasi", kelengkapan: "Dengan Lensa 16-50mm & Memory Card"},
            {id: 18, kodeUnit: "TRP001", namaUnit: "Tripod", prodi: "Teknologi Informasi", kelengkapan: "Dengan Tas"},
            {id: 19, kodeUnit: "IBD001", namaUnit: "Interactive Board", prodi: "Teknologi Informasi", kelengkapan: "Dengan Stylus & Kabel USB"},
            {id: 20, kodeUnit: "DCM001", namaUnit: "Document Camera", prodi: "Teknologi Informasi", kelengkapan: "Dengan Kabel USB"},
            {id: 21, kodeUnit: "SCR001", namaUnit: "Screen Tabung", prodi: "Teknologi Informasi", kelengkapan: "Dengan Kabel Power & VGA"},
            {id: 22, kodeUnit: "TV001", namaUnit: "TV LED 32\"", prodi: "Teknologi Informasi", kelengkapan: "Dengan Kabel Power & HDMI"}
        ];
        
        // Event listener untuk jenis peminjaman
        document.getElementById('jenis').addEventListener('change', function() {
            const jenis = this.value;
            const ruanganSection = document.getElementById('ruanganSection');
            const unitSection = document.getElementById('unitSection');
            
            if (jenis === 'ruangan') {
                ruanganSection.style.display = 'block';
                unitSection.style.display = 'none';
                document.getElementById('ruangan').required = true;
                document.getElementById('unit').required = false;
            } else if (jenis === 'unit') {
                ruanganSection.style.display = 'none';
                unitSection.style.display = 'block';
                document.getElementById('ruangan').required = false;
                document.getElementById('unit').required = true;
            } else {
                ruanganSection.style.display = 'none';
                unitSection.style.display = 'none';
                document.getElementById('ruangan').required = false;
                document.getElementById('unit').required = false;
            }
        });
        
        // Event listener untuk ruangan
        document.getElementById('ruangan').addEventListener('change', function() {
            const ruanganId = this.value;
            const ruanganInfo = document.getElementById('ruanganInfo');
            
            if (ruanganId) {
                const ruangan = dataRuangan.find(r => r.id == ruanganId);
                if (ruangan) {
                    document.getElementById('infoNamaRuangan').textContent = ruangan.namaRuangan;
                    document.getElementById('infoKapasitas').textContent = ruangan.kapasitas + ' orang';
                    document.getElementById('infoLokasi').textContent = ruangan.lokasi;
                    document.getElementById('infoProdi').textContent = ruangan.prodi;
                    ruanganInfo.style.display = 'block';
                }
            } else {
                ruanganInfo.style.display = 'none';
            }
        });
        
        // Event listener untuk unit
        document.getElementById('unit').addEventListener('change', function() {
            const unitId = this.value;
            const unitInfo = document.getElementById('unitInfo');
            
            if (unitId) {
                const unit = dataUnit.find(u => u.id == unitId);
                if (unit) {
                    document.getElementById('infoNamaUnit').textContent = unit.namaUnit;
                    document.getElementById('infoKodeUnit').textContent = unit.kodeUnit;
                    document.getElementById('infoProdiUnit').textContent = unit.prodi;
                    document.getElementById('infoKelengkapanUnit').textContent = unit.kelengkapan;
                    unitInfo.style.display = 'block';
                }
            } else {
                unitInfo.style.display = 'none';
            }
        });
        
        // Set minimum date to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('tanggalPinjam').setAttribute('min', today);
    </script>
</body>
</html>