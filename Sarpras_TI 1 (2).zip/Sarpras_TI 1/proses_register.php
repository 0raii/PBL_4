<?php
// Tampilkan semua error
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../config.php';

// Proses registrasi
if (isset($_POST['register'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirmPassword = mysqli_real_escape_string($conn, $_POST['confirmPassword']);
    $namaLengkap = mysqli_real_escape_string($conn, $_POST['namaLengkap']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $nim = mysqli_real_escape_string($conn, $_POST['nim']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);
    $prodi = mysqli_real_escape_string($conn, $_POST['prodi']);
    
    // Validasi password
    if ($password != $confirmPassword) {
        $_SESSION['error'] = "Password dan konfirmasi password tidak cocok!";
        header("Location: ../register.php");
        exit();
    } else {
        // Cek apakah username sudah ada
        $query = "SELECT * FROM mahasiswa WHERE username='$username'";
        $result = mysqli_query($conn, $query);
        
        if (mysqli_num_rows($result) > 0) {
            $_SESSION['error'] = "Username sudah digunakan!";
            header("Location: ../register.php");
            exit();
        } else {
            // Cek apakah email sudah ada
            $query = "SELECT * FROM mahasiswa WHERE email='$email'";
            $result = mysqli_query($conn, $query);
            
            if (mysqli_num_rows($result) > 0) {
                $_SESSION['error'] = "Email sudah digunakan!";
                header("Location: ../register.php");
                exit();
            } else {
                // Cek apakah NIM sudah ada
                $query = "SELECT * FROM mahasiswa WHERE nim='$nim'";
                $result = mysqli_query($conn, $query);
                
                if (mysqli_num_rows($result) > 0) {
                    $_SESSION['error'] = "NIM sudah digunakan!";
                    header("Location: ../register.php");
                    exit();
                } else {
                    // Hash password
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    
                    // Insert user baru
                    $query = "INSERT INTO mahasiswa (username, password, namaLengkap, email, nim, role, prodi) 
                              VALUES ('$username', '$hashedPassword', '$namaLengkap', '$email', '$nim', '$role', '$prodi')";
                    
                    if (mysqli_query($conn, $query)) {
                        $_SESSION['success'] = "Registrasi berhasil! Silakan login dengan akun Anda.";
                        
                        // Jika role dosen atau staff, buat record di tabel dosen/staff
                        if ($role == 'dosen') {
                            $userId = mysqli_insert_id($conn);
                            $nipDosen = "DOS" . date('Ym') . sprintf("%03d", $userId);
                            
                            $query = "INSERT INTO dosen (idMahasiswa, nipDosen, email, namaLengkap, noHp) 
                                      VALUES ($userId, '$nipDosen', '$email', '$namaLengkap', '-')";
                            mysqli_query($conn, $query);
                        } elseif ($role == 'staff') {
                            $userId = mysqli_insert_id($conn);
                            $nipStaff = "STF" . date('Ym') . sprintf("%03d", $userId);
                            
                            $query = "INSERT INTO staff (idMahasiswa, nipStaff, email, namaLengkap, noHp) 
                                      VALUES ($userId, '$nipStaff', '$email', '$namaLengkap', '-')";
                            mysqli_query($conn, $query);
                        }
                        
                        header("Location: ../index.php");
                        exit();
                    } else {
                        $_SESSION['error'] = "Registrasi gagal: " . mysqli_error($conn);
                        header("Location: ../register.php");
                        exit();
                    }
                }
            }
        }
    }
} else {
    header("Location: ../register.php");
    exit();
}
?>