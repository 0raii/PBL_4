<?php
include 'config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

// Ambil data user
$user_id = $_SESSION['id'];
$query = "SELECT * FROM mahasiswa WHERE id=$user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

// Ambil data dosen/staff jika role-nya dosen/staff
if ($user['role'] == 'dosen') {
    $query_dosen = "SELECT * FROM dosen WHERE idMahasiswa=$user_id";
    $result_dosen = mysqli_query($conn, $query_dosen);
    $dosen = mysqli_fetch_assoc($result_dosen);
    $user_id_number = $dosen['nipDosen'];
    $user_type = "Dosen";
    $user_icon = "fas fa-user-tie";
} elseif ($user['role'] == 'staff') {
    $query_staff = "SELECT * FROM staff WHERE idMahasiswa=$user_id";
    $result_staff = mysqli_query($conn, $query_staff);
    $staff = mysqli_fetch_assoc($result_staff);
    $user_id_number = $staff['nipStaff'];
    $user_type = "Staff";
    $user_icon = "fas fa-user-hard-hat";
} else { // mahasiswa
    $user_id_number = $user['nim'];
    $user_type = "Mahasiswa";
    $user_icon = "fas fa-user-graduate";
}

// Ambil data peminjaman
if (isset($_GET['id'])) {
    $peminjaman_id = $_GET['id'];
    
    $query_peminjaman = "SELECT p.*, r.namaRuangan, u.namaUnit 
                        FROM peminjaman p 
                        LEFT JOIN ruangan r ON p.idRuangan = r.id 
                        LEFT JOIN unit u ON p.idUnit = u.id 
                        WHERE p.id = $peminjaman_id AND p.idMahasiswa = $user_id AND p.status = 'disetujui'";
    $result_peminjaman = mysqli_query($conn, $query_peminjaman);
    
    if (mysqli_num_rows($result_peminjaman) == 0) {
        if ($user['role'] == 'admin') {
            header("Location: admin_dashboard.php");
        } elseif ($user['role'] == 'dosen' || $user['role'] == 'staff') {
            header("Location: dosen_dashboard.php");
        } else {
            header("Location: dashboard.php");
        }
        exit();
    }
    
    $peminjaman = mysqli_fetch_assoc($result_peminjaman);
} else {
    if ($user['role'] == 'admin') {
        header("Location: admin_dashboard.php");
    } elseif ($user['role'] == 'dosen' || $user['role'] == 'staff') {
        header("Location: dosen_dashboard.php");
    } else {
        header("Location: dashboard.php");
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengembalian - Sistem Peminjaman Sarpras</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>Sarpras TI</h2>
            </div>
            
            <div class="sidebar-user">
                <div class="user-avatar">
                    <i class="<?php echo $user_icon; ?>"></i>
                </div>
                <div class="user-info">
                    <h3><?php echo $user['namaLengkap']; ?></h3>
                    <p><?php echo $user_type; ?></p>
                    <p class="user-nip"><?php echo $user_id_number; ?></p>
                </div>
            </div>
            
            <ul class="sidebar-menu">
                <?php if ($user['role'] == 'admin'): ?>
                    <li><a href="dashboard admin.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <?php elseif ($user['role'] == 'dosen' || $user['role'] == 'staff'): ?>
                    <li><a href="dashboard dosen.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <?php else: ?>
                    <li><a href="dashboard users.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <?php endif; ?>
                <li><a href="peminjaman.php"><i class="fas fa-plus-circle"></i> Ajukan Peminjaman</a></li>
                <li><a href="riwayat.php"><i class="fas fa-history"></i> Riwayat Peminjaman</a></li>
                <li><a href="notifikasi.php"><i class="fas fa-bell"></i> Notifikasi</a></li>
                <li><a href="process/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Form Pengembalian</h1>
                <div class="header-info">
                    <span><?php echo date('d F Y'); ?></span>
                </div>
            </div>
            
            <div class="form-container">
                <div class="peminjaman-info">
                    <h2>Informasi Peminjaman</h2>
                    <div class="info-grid">
                        <div class="info-item">
                            <span class="info-label">ID Peminjaman:</span>
                            <span class="info-value">#<?php echo $peminjaman['id']; ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Tanggal Pinjam:</span>
                            <span class="info-value"><?php echo date('d/m/Y', strtotime($peminjaman['tanggalPinjam'])); ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Jam:</span>
                            <span class="info-value"><?php echo date('H:i', strtotime($peminjaman['jamMulai'])) . ' - ' . date('H:i', strtotime($peminjaman['jamSelesai'])); ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Ruangan/Unit:</span>
                            <span class="info-value">
                                <?php 
                                if ($peminjaman['idRuangan']) {
                                    echo $peminjaman['namaRuangan'];
                                } elseif ($peminjaman['idUnit']) {
                                    echo $peminjaman['namaUnit'];
                                } else {
                                    echo '-';
                                }
                                ?>
                            </span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Keperluan:</span>
                            <span class="info-value"><?php echo $peminjaman['keperluan']; ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Status:</span>
                            <span class="info-value">
                                <span class="status-badge status-<?php echo $peminjaman['status']; ?>">
                                    <?php echo ucfirst($peminjaman['status']); ?>
                                </span>
                            </span>
                        </div>
                    </div>
                </div>
                
                <form action="process/tambah_pengembalian.php" method="post" id="formPengembalian">
                    <input type="hidden" name="idPeminjaman" value="<?php echo $peminjaman['id']; ?>">
                    
                    <div class="form-section">
                        <h2>Informasi Pengembalian</h2>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="tanggalKembali">Tanggal Kembali</label>
                                <input type="date" id="tanggalKembali" name="tanggalKembali" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                            
                            <div class="form-group">
                                <label for="jamKembali">Jam Kembali</label>
                                <input type="time" id="jamKembali" name="jamKembali" value="<?php echo date('H:i'); ?>" required>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="kondisi">Kondisi</label>
                            <select id="kondisi" name="kondisi" required>
                                <option value="baik">Baik</option>
                                <option value="rusak">Rusak</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="catatan">Catatan</label>
                            <textarea id="catatan" name="catatan" rows="3"></textarea>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Kirim Pengembalian</button>
                        <a href="<?php 
                            if ($user['role'] == 'admin') {
                                echo 'admin_dashboard.php';
                            } elseif ($user['role'] == 'dosen' || $user['role'] == 'staff') {
                                echo 'dosen_dashboard.php';
                            } else {
                                echo 'dashboard.php';
                            }
                        ?>" class="btn btn-outline">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="assets/js/script.js"></script>
    <script>
        // Set maximum date to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('tanggalKembali').setAttribute('max', today);
        
        // Show/hide catatan field based on kondisi
        document.getElementById('kondisi').addEventListener('change', function() {
            const catatanField = document.getElementById('catatan');
            if (this.value === 'rusak') {
                catatanField.setAttribute('required', 'required');
            } else {
                catatanField.removeAttribute('required');
            }
        });
    </script>
</body>
</html>