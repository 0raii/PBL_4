<?php
// Tampilkan semua error
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'config.php';

echo "<h1>Buat User Admin</h1>";

$username = "admin";
$password = password_hash("admin123", PASSWORD_DEFAULT);
$namaLengkap = "Administrator";
$email = "admin@example.com";
$nim = "ADMIN001";
$role = "admin";
$prodi = "Teknik Informatika";

// Cek apakah username sudah ada
$query = "SELECT * FROM mahasiswa WHERE username='$username'";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    echo "<p style='color: orange;'>Username '$username' sudah ada!</p>";
} else {
    // Insert user admin
    $query = "INSERT INTO mahasiswa (username, password, namaLengkap, email, nim, role, prodi) 
              VALUES ('$username', '$password', '$namaLengkap', '$email', '$nim', '$role', '$prodi')";
    
    if (mysqli_query($conn, $query)) {
        echo "<p style='color: green;'>User admin berhasil dibuat!</p>";
        echo "<p>Username: $username</p>";
        echo "<p>Password: admin123</p>";
    } else {
        echo "<p style='color: red;'>Gagal membuat user admin: " . mysqli_error($conn) . "</p>";
    }
}

echo "<p><a href='index.php'>Kembali ke Halaman Utama</a></p>";
?>