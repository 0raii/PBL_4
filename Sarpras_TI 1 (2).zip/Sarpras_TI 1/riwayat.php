<?php
include 'config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

// Ambil data user
$user_id = $_SESSION['id'];
$query = "SELECT * FROM mahasiswa WHERE id=$user_id";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

// Ambil data dosen/staff jika role-nya dosen/staff
if ($user['role'] == 'dosen') {
    $query_dosen = "SELECT * FROM dosen WHERE idMahasiswa=$user_id";
    $result_dosen = mysqli_query($conn, $query_dosen);
    $dosen = mysqli_fetch_assoc($result_dosen);
    $user_id_number = $dosen['nipDosen'];
    $user_type = "Dosen";
    $user_icon = "fas fa-user-tie";
} elseif ($user['role'] == 'staff') {
    $query_staff = "SELECT * FROM staff WHERE idMahasiswa=$user_id";
    $result_staff = mysqli_query($conn, $query_staff);
    $staff = mysqli_fetch_assoc($result_staff);
    $user_id_number = $staff['nipStaff'];
    $user_type = "Staff";
    $user_icon = "fas fa-user-hard-hat";
} else { // mahasiswa
    $user_id_number = $user['nim'];
    $user_type = "Mahasiswa";
    $user_icon = "fas fa-user-graduate";
}

// Ambil data peminjaman
$query_peminjaman = "SELECT p.*, r.namaRuangan, u.namaUnit 
                    FROM peminjaman p 
                    LEFT JOIN ruangan r ON p.idRuangan = r.id 
                    LEFT JOIN unit u ON p.idUnit = u.id 
                    WHERE p.idMahasiswa = $user_id 
                    ORDER BY p.created_at DESC";
$peminjaman = mysqli_query($conn, $query_peminjaman);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Peminjaman - Sistem Peminjaman Sarpras</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h2>Sarpras TI</h2>
            </div>
            
            <div class="sidebar-user">
                <div class="user-avatar">
                    <i class="<?php echo $user_icon; ?>"></i>
                </div>
                <div class="user-info">
                    <h3><?php echo $user['namaLengkap']; ?></h3>
                    <p><?php echo $user_type; ?></p>
                    <p class="user-nip"><?php echo $user_id_number; ?></p>
                </div>
            </div>
            
            <ul class="sidebar-menu">
                <?php if ($user['role'] == 'admin'): ?>
                    <li><a href="dashboard admin.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <?php elseif ($user['role'] == 'dosen' || $user['role'] == 'staff'): ?>
                    <li><a href="dashboard dosen.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <?php else: ?>
                    <li><a href="dashboard users.php"><i class="fas fa-home"></i> Dashboard</a></li>
                <?php endif; ?>
                <li><a href="peminjaman.php"><i class="fas fa-plus-circle"></i> Ajukan Peminjaman</a></li>
                <li class="active"><a href="riwayat.php"><i class="fas fa-history"></i> Riwayat Peminjaman</a></li>
                <li><a href="notifikasi.php"><i class="fas fa-bell"></i> Notifikasi</a></li>
                <li><a href="process/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Riwayat Peminjaman</h1>
                <div class="header-info">
                    <span><?php echo date('d F Y'); ?></span>
                </div>
            </div>
            
            <div class="table-container">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tanggal Pinjam</th>
                            <th>Jam</th>
                            <th>Ruangan/Unit</th>
                            <th>Keperluan</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($peminjaman) > 0): ?>
                            <?php while ($p = mysqli_fetch_assoc($peminjaman)): ?>
                                <tr>
                                    <td>#<?php echo $p['id']; ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($p['tanggalPinjam'])); ?></td>
                                    <td><?php echo date('H:i', strtotime($p['jamMulai'])) . ' - ' . date('H:i', strtotime($p['jamSelesai'])); ?></td>
                                    <td>
                                        <?php 
                                        if ($p['idRuangan']) {
                                            echo $p['namaRuangan'];
                                        } elseif ($p['idUnit']) {
                                            echo $p['namaUnit'];
                                        } else {
                                            echo '-';
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo $p['keperluan']; ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $p['status']; ?>">
                                            <?php echo ucfirst($p['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($p['status'] == 'disetujui'): ?>
                                            <a href="pengembalian.php?id=<?php echo $p['id']; ?>" class="btn btn-sm btn-success">Kembalikan</a>
                                        <?php elseif ($p['status'] == 'pending'): ?>
                                            <a href="javascript:void(0)" onclick="batalPeminjaman(<?php echo $p['id']; ?>)" class="btn btn-sm btn-danger">Batalkan</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center">Belum ada data peminjaman</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <script src="assets/js/script.js"></script>
    <script>
        function batalPeminjaman(id) {
            if (confirm('Apakah Anda yakin ingin membatalkan peminjaman ini?')) {
                window.location.href = 'process/update_status.php?id=' + id + '&status=batal';
            }
        }
    </script>
</body>
</html>