<?php
include '../config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['id'])) {
header("Location: ../index.php");
exit();
}

$user_id = $_SESSION['id'];
$user_role = $_SESSION['role'];

if (isset($_POST['jenis'])) {
$jenis = $_POST['jenis'];
$tanggalPinjam = $_POST['tanggalPinjam'];
$jamMulai = $_POST['jamMulai'];
$jamSelesai = $_POST['jamSelesai'];
$keperluan = $_POST['keperluan'];
$prioritas = $_POST['prioritas'];

$idRuangan = null;
$idUnit = null;

if ($jenis == 'ruangan') {
$idRuangan = $_POST['idRuangan'];
} elseif ($jenis == 'unit') {
$idUnit = $_POST['idUnit'];
}

// Insert peminjaman
$query = "INSERT INTO peminjaman (idMahasiswa, idRuangan, idUnit, tanggalPinjam, jamMulai, jamSelesai, keperluan, prioritas, status) 
VALUES ($user_id, " . ($idRuangan ? $idRuangan : "NULL") . ", " . ($idUnit ? $idUnit : "NULL") . ", '$tanggalPinjam', '$jamMulai', '$jamSelesai', '$keperluan', '$prioritas', 'pending')";

if (mysqli_query($conn, $query)) {
$peminjaman_id = mysqli_insert_id($conn);

// Tambah notifikasi untuk admin
// Ambil ID admin dari tabel mahasiswa
$query_admin_id = "SELECT id FROM mahasiswa WHERE role = 'admin' LIMIT 1";
$result_admin_id = mysqli_query($conn, $query_admin_id);

if ($result_admin_id && mysqli_num_rows($result_admin_id) > 0) {
$admin_data = mysqli_fetch_assoc($result_admin_id);
$admin_id = $admin_data['id'];

$pesan = "Peminjaman baru telah diajukan oleh " . ucfirst($user_role) . " dengan ID #$peminjaman_id";
$query_notifikasi = "INSERT INTO notifikasi (idUser, idPeminjaman, pesan, status) VALUES ('$admin_id', '$peminjaman_id', '$pesan', 'terkirim')";
mysqli_query($conn, $query_notifikasi);
}

$_SESSION['success'] = "Peminjaman berhasil diajukan!";

// Redirect sesuai role
if ($user_role == 'admin') {
header("Location: ../dashboard admin.php");
} elseif ($user_role == 'dosen' || $user_role == 'staff') {
header("Location: ../dashboard dosen.php");
} else { // mahasiswa
header("Location: ../dashboard users.php");
}
exit();
} else {
$_SESSION['error'] = "Gagal mengajukan peminjaman: " . mysqli_error($conn);

// Redirect sesuai role
if ($user_role == 'admin') {
header("Location: ../dashboard admin.php");
} elseif ($user_role == 'dosen' || $user_role == 'staff') {
header("Location: ../dashboard dosen.php");
} else { // mahasiswa
header("Location: ../dashboard users.php");
}
exit();
}
} else {
// Redirect sesuai role
if ($user_role == 'admin') {
header("Location: ../dashboard admin.php");
} elseif ($user_role == 'dosen' || $user_role == 'staff') {
header("Location: ../dashboard dosen.php");
} else { // mahasiswa
header("Location: ../dashboard users.php");
}
exit();
}
?>