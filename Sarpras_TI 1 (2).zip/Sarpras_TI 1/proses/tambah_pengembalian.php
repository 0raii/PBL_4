<?php
include '../config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['id'])) {
    header("Location: ../index.php");
    exit();
}

$user_role = $_SESSION['role'];

if (isset($_POST['idPeminjaman'])) {
    $idPeminjaman = $_POST['idPeminjaman'];
    $tanggalKembali = $_POST['tanggalKembali'];
    $jamKembali = $_POST['jamKembali'];
    $kondisi = $_POST['kondisi'];
    $catatan = $_POST['catatan'];
    
    // Insert pengembalian
    $query = "INSERT INTO pengembalian (idPeminjaman, tanggalKembali, jamKembali, kondisi, catatan) 
              VALUES ($idPeminjaman, '$tanggalKembali', '$jamKembali', '$kondisi', '$catatan')";
    
    if (mysqli_query($conn, $query)) {
        // Update status peminjaman menjadi selesai
        $query_update = "UPDATE peminjaman SET status='selesai' WHERE id=$idPeminjaman";
        mysqli_query($conn, $query_update);
        
        // Get peminjaman data
        $query_peminjaman = "SELECT * FROM peminjaman WHERE id=$idPeminjaman";
        $result_peminjaman = mysqli_query($conn, $query_peminjaman);
        $peminjaman = mysqli_fetch_assoc($result_peminjaman);
        
        // Update status ruangan/unit menjadi tersedia
        if ($peminjaman['idRuangan']) {
            $query_ruangan = "UPDATE ruangan SET status='tersedia' WHERE id=" . $peminjaman['idRuangan'];
            mysqli_query($conn, $query_ruangan);
        } elseif ($peminjaman['idUnit']) {
            $query_unit = "UPDATE unit SET status='tersedia' WHERE id=" . $peminjaman['idUnit'];
            mysqli_query($conn, $query_unit);
        }
        
        // Jika kondisi rusak, update status ruangan/unit menjadi perbaikan
        if ($kondisi == 'rusak') {
            if ($peminjaman['idRuangan']) {
                $query_ruangan = "UPDATE ruangan SET status='perbaikan' WHERE id=" . $peminjaman['idRuangan'];
                mysqli_query($conn, $query_ruangan);
            } elseif ($peminjaman['idUnit']) {
                $query_unit = "UPDATE unit SET status='perbaikan' WHERE id=" . $peminjaman['idUnit'];
                mysqli_query($conn, $query_unit);
            }
        }
        
        $_SESSION['success'] = "Pengembalian berhasil dicatat!";
        
        // Redirect sesuai role
        if ($user_role == 'admin') {
            header("Location: ../dashboard admin.php");
        } elseif ($user_role == 'dosen' || $user_role == 'staff') {
            header("Location: ../dashboard dosen.php");
        } else { // mahasiswa
            header("Location: ../dashboard users.php");
        }
        exit();
    } else {
        $_SESSION['error'] = "Gagal mencatat pengembalian: " . mysqli_error($conn);
        header("Location: ../pengembalian.php?id=" . $idPeminjaman);
        exit();
    }
} else {
    // Redirect sesuai role
    if ($user_role == 'admin') {
        header("Location: ../admin_dashboard.php");
    } elseif ($user_role == 'dosen' || $user_role == 'staff') {
        header("Location: ../dosen_dashboard.php");
    } else { // mahasiswa
        header("Location: ../dashboard.php");
    }
    exit();
}
?>